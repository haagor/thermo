#include <stdio.h>
#include <stdlib.h>
#include <math.h>


struct Cell {
	float cell1;
	float cell2;
	int constant;
};

void print_matrix(struct Cell* matrix, int N, int even)
{
	for (int row = 0; row < N; row++)
	{
		printf("\n");
		for (int column = 0; column < N; column++)
		{
			struct Cell* c = matrix + (row * N) + column;
			if (even)
			{
				printf("% 7.2f", c->cell2);
			} else {
				printf("% 7.2f", c->cell1);
			}
		}
	}
}

void init_matrix(int n, float T, struct Cell* matrix)
{
	int N = pow(2,n) + 2;				// taille de la matrice	(+2 pour le bord froid)	_ DECALAGE bit bit

	// calcul des cellules chauffées
	float heat = 1 << (n - 1);		
	int miHeat = heat - (1 << (n - 4));
	int maHeat = heat + (1 << (n - 4));

	int row, column;
	int hot, cold;
	struct Cell* c;
	for (row = 0; row < N; row++)	//init a retravailler pour heat
	{
		if (row > miHeat && row <= maHeat)
		{
			hot = 1;
		} else {
			hot = 0;
		}
		if (row == 0 || row == N-1)
		{
			cold = 1;
		} else {
			cold = 0;
		}
		for (column = 0; column < N; column++)
		{
			c = matrix + (row * N) + column;
			if (column > miHeat && column <= maHeat && hot)
			{
				c->cell1 = T;
				c->cell2 = T;
				c->constant = 1;
			} 
			else if (column == N - 1 || column == 0 || cold)
			{
				c->cell1 = 0;
				c->cell2 = 0;
				c->constant = 1;
			} else {
				c->cell1 = 0;
				c->cell2 = 0;
				c->constant = 0;
			}
		}
	}
}

void rinit_matrix(int n, float T, struct Cell* matrix)
{
	int N = pow(2,n) + 2;				// taille de la matrice	(+2 pour le bord froid)	_ DECALAGE bit bit

	// calcul des cellules chauffées
	float heat = 1 << (n - 1);		
	int miHeat = heat - (1 << (n - 4));
	int maHeat = heat + (1 << (n - 4));

	int row, column;
	int hot, cold;
	struct Cell* c;
	for (row = 0; row < N; row++)	//init a retravailler pour heat
	{
		if (row > miHeat && row <= maHeat)
		{
			hot = 1;
		} else {
			hot = 0;
		}
		if (row == 0 || row == N-1)
		{
			cold = 1;
		} else {
			cold = 0;
		}
		for (column = 0; column < N; column++)
		{
			c = matrix + (row * N) + column;
			if (column > miHeat && column <= maHeat && hot)
			{
				c->cell1 = T;
				c->cell2 = T;
				c->constant = 1;
			}
			else if (column == N-1 || column == 0 || cold)
			{
				c->cell1 = 0;
				c->cell2 = 0;
				c->constant = 1;
			}
		}
	}
}

void verticale_iter_impair(struct Cell* matrix, int N)
{
	struct Cell* cUp;
	struct Cell* cDown;
	struct Cell* c;

	for (int row = 0; row < N; row++)
	{

		for (int column = 0; column < N; column++)
		{
			c = matrix + row * N + column;
			cUp = matrix + (row - 1) * N + column;
			cDown = matrix + (row + 1) * N + column;

			if (row == 0)
			{
				c->cell1 = (2 * (c->cell2 / 3)) + (cDown->cell2 / 6);
			}
			else if (row == N - 1)
			{
				c->cell1 = (2 * (c->cell2 / 3)) + (cUp->cell2 / 6);
			} else {
				c->cell1 = (2 * (c->cell2 / 3)) + (cUp->cell2 / 6) + (cDown->cell2 / 6);
			}
		}
	}
}

void horizontale_iter_pair(struct Cell* matrix, int N)
{
	struct Cell* cLeft;
	struct Cell* cRight;
	struct Cell* c;

	for (int row = 0; row < N; row++)
	{

		for (int column = 0; column < N; column++)
		{
			c = matrix + (row * N) + column;
			cLeft = matrix + (row * N) + column - 1;
			cRight = matrix + (row * N) + column + 1;

			if (column == 0)
			{
				c->cell2 = (2 * (c->cell1 / 3)) + (cRight->cell1 / 6);
			}
			else if (column == N - 1)
			{
				c->cell2 = (2 * (c->cell1 / 3)) + (cLeft->cell1 / 6);
			} else {
				c->cell2 = (2 * (c->cell1 / 3)) + (cLeft->cell1 / 6) + (cRight->cell1 / 6);
			}

		}
	}
}

void iter(struct Cell* matrix, int n, int N, float T, int nb_iter)
{
	for (int w = 0; w < nb_iter; w++) // nombre d'itération verticale
	{
		horizontale_iter_pair(matrix, N);
		verticale_iter_impair(matrix, N);

		rinit_matrix(n, T, matrix);
	}
}


int main()
{

	float T = 36;							// temperature
	int n = 4;								// [4-9]
	int N = (1 << n) + 2;					// taille de la matrice	(+2 pour le bord froid)	_ DECALAGE bit bit
	struct Cell matrice[N*N];				// init matrice
	int nb_iter = 10000;					// nombre d'iteration

	init_matrix(n, T, matrice);

	iter(matrice, n, N, T, nb_iter);
	print_matrix(matrice, N, 0);
	printf("\n -------------------------------");
	printf("\n");

}
